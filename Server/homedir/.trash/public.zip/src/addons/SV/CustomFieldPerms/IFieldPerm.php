<?php


namespace SV\CustomFieldPerms;


/**
 * used to tag a Field entity as supported custom fields
 *
 * @package SV\CustomFieldPerms
 */
interface IFieldPerm
{

}
