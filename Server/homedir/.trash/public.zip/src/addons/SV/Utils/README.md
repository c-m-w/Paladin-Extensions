# XenForo2-Utils
 Standardized utilities that all my XenForo2 Addons use

Example `build.json` to include these files, assuming https://github.com/Xon/XenForo2-Utils is cloned to src/addons/SV/Utils

```json
{
  "additional_files": [
    "src/addons/SV/Utils/"
  ]
}
```